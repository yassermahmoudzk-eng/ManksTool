[app]
title = Manks Tool
package.name = mankstool
package.domain = com.manks

source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf,so,jar,txt,lua,pak,json
source.include_patterns = tools/*,assets/*,LUA/*
source.exclude_dirs = bin, .buildozer, __pycache__, PAK, REPACK, RESULT, LOGS, UNPACK

version = 1.0.0

requirements = python3,kivy==2.3.0,requests,pycryptodome,pyjnius,android

orientation = portrait
fullscreen = 0

icon.filename = %(source.dir)s/assets/icon.png

android.permissions = READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE, INTERNET
android.api = 33
android.minapi = 21
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = True
android.add_src = tools/

[buildozer]
log_level = 2
warn_on_root = 1