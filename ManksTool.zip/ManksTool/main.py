# main.py
import os
import sys
import threading
import traceback
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.metrics import dp
from kivy.properties import StringProperty, BooleanProperty, ListProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.textinput import TextInput
from kivy.core.window import Window
from kivy.utils import platform

# ====== مسار البيانات (مهم لأندرويد) ======
if platform == 'android':
    from android.storage import primary_external_storage_path
    from android.permissions import request_permissions, Permission
    request_permissions([
        Permission.READ_EXTERNAL_STORAGE,
        Permission.WRITE_EXTERNAL_STORAGE,
    ])
    DATA_PATH = Path(primary_external_storage_path()) / "ManksTool"
else:
    DATA_PATH = Path(__file__).parent

DATA_PATH.mkdir(parents=True, exist_ok=True)

# استيراد الأدوات المنفصلة
from tools import auth, pak_tool, lua_tool

# ====== واجهة Kivy KV ======
KV = '''
<MenuScreen>:
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.04, 0.05, 0.08, 1
            Rectangle:
                pos: self.pos
                size: self.size

        Label:
            text: 'MANKS TOOL'
            font_size: '32sp'
            bold: True
            color: 0, 0.83, 1, 1
            size_hint_y: 0.12

        Label:
            text: 'DEV @Cil_t & @AhmedVlP0'
            font_size: '12sp'
            color: 0.5, 0.5, 0.5, 1
            size_hint_y: 0.06

        ScrollView:
            BoxLayout:
                id: menu_box
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(20)
                spacing: dp(10)

<OutputScreen>:
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.04, 0.05, 0.08, 1
            Rectangle:
                pos: self.pos
                size: self.size

        Label:
            text: root.title_text
            font_size: '20sp'
            bold: True
            color: 0, 0.83, 1, 1
            size_hint_y: 0.1

        ScrollView:
            id: scroll
            Label:
                id: output_label
                text: root.output_text
                size_hint_y: None
                height: self.texture_size[1]
                text_size: self.width, None
                padding: dp(10)
                font_size: '11sp'
                color: 0.9, 0.9, 0.9, 1
                markup: True

        Button:
            text: 'BACK'
            size_hint_y: 0.1
            background_color: 0.1, 0.1, 0.2, 1
            color: 0, 0.83, 1, 1
            on_release: app.go_back()
'''

Builder.load_string(KV)


# ====== شاشة القائمة ======
class MenuScreen(Screen):
    def on_enter(self):
        self.build_menu()

    def build_menu(self):
        box = self.ids.menu_box
        box.clear_widgets()

        options = [
            ('1.  UNPACK PAKS',        self.action_unpack,        (0, 1, 0.7, 1)),
            ('2.  REPACK NORMAL',      self.action_repack_normal, (0, 1, 0.53, 1)),
            ('3.  REPACK FULL SIZE',   self.action_repack_full,   (1, 0.84, 0, 1)),
            ('4.  INJECT NEW FILES',   self.action_inject,        (1, 0.27, 0.34, 1)),
            ('5.  DELETE FOLDER',      self.action_delete,        (1, 0.27, 0.34, 1)),
            ('6.  COMPILE LUA',        self.action_compile_lua,   (0, 1, 0.53, 1)),
            ('7.  DECOMPILE LUA',      self.action_decompile_lua, (0, 0.83, 1, 1)),
            ('0.  EXIT',               self.action_exit,          (0.5, 0.5, 0.5, 1)),
        ]

        for text, cb, color in options:
            btn = Button(
                text=text,
                size_hint_y=None,
                height=dp(55),
                background_normal='',
                background_color=(0.1, 0.12, 0.18, 1),
                color=color,
                font_size='15sp',
                bold=True,
            )
            btn.bind(on_release=cb)
            box.add_widget(btn)

    # ====== دوال الأزرار ======
    def action_unpack(self, *a):
        self._run_task("UNPACK PAKS", pak_tool.do_unpack, DATA_PATH)

    def action_repack_normal(self, *a):
        self._run_task("REPACK NORMAL", pak_tool.do_repack_normal, DATA_PATH)

    def action_repack_full(self, *a):
        self._run_task("REPACK FULL SIZE", pak_tool.do_repack_full, DATA_PATH)

    def action_inject(self, *a):
        self._run_task("INJECT NEW FILES", pak_tool.do_inject, DATA_PATH)

    def action_compile_lua(self, *a):
        self._run_task("COMPILE LUA", lua_tool.do_compile, DATA_PATH)

    def action_decompile_lua(self, *a):
        self._run_task("DECOMPILE LUA", lua_tool.do_decompile, DATA_PATH)

    def action_delete(self, *a):
        self._show_delete_dialog()

    def action_exit(self, *a):
        App.get_running_app().stop()

    def _run_task(self, title, func, *args):
        """تشغيل المهمة في خيط منفصل لتجنب تجميد الواجهة"""
        app = App.get_running_app()
        app.show_output(title, "⏳ Processing...\n")

        def worker():
            def log(msg):
                Clock.schedule_once(lambda dt: app.append_output(str(msg)), 0)
            try:
                func(*args, log=log)
                Clock.schedule_once(lambda dt: app.append_output("\n✅ DONE"), 0)
            except Exception as e:
                tb = traceback.format_exc()
                Clock.schedule_once(
                    lambda dt: app.append_output(f"\n❌ ERROR: {e}\n{tb}"), 0
                )

        threading.Thread(target=worker, daemon=True).start()

    def _show_delete_dialog(self):
        folders = [f for f in DATA_PATH.iterdir()
                   if f.is_dir() and f.name not in
                   ['PAK', 'UNPACK', 'REPACK', 'RESULT', 'PAK TOOL', 'LOGS', 'LUA', 'assets']]
        if not folders:
            self._toast("No folders to delete")
            return

        content = BoxLayout(orientation='vertical', spacing=dp(5), padding=dp(10))
        scroll = ScrollView()
        inner = BoxLayout(orientation='vertical', size_hint_y=None, spacing=dp(5))
        inner.bind(minimum_height=inner.setter('height'))

        popup_holder = {}

        for f in folders:
            b = Button(text=f.name, size_hint_y=None, height=dp(45),
                       background_normal='', background_color=(0.15, 0.15, 0.25, 1))
            def make_cb(folder=f):
                def cb(*a):
                    import shutil
                    try:
                        shutil.rmtree(folder)
                        self._toast(f"Deleted: {folder.name}")
                    except Exception as e:
                        self._toast(f"Error: {e}")
                    if 'popup' in popup_holder:
                        popup_holder['popup'].dismiss()
                return cb
            b.bind(on_release=make_cb())
            inner.add_widget(b)

        scroll.add_widget(inner)
        content.add_widget(scroll)

        close_btn = Button(text="CANCEL", size_hint_y=None, height=dp(45),
                           background_color=(0.3, 0.1, 0.1, 1))
        content.add_widget(close_btn)

        popup = Popup(title="Select folder to DELETE", content=content,
                      size_hint=(0.9, 0.8))
        popup_holder['popup'] = popup
        close_btn.bind(on_release=lambda *a: popup.dismiss())
        popup.open()

    def _toast(self, msg):
        popup = Popup(title="", content=Label(text=msg), size_hint=(0.7, 0.2))
        popup.open()
        Clock.schedule_once(lambda dt: popup.dismiss(), 1.5)


# ====== شاشة المخرجات ======
class OutputScreen(Screen):
    title_text = StringProperty("")
    output_text = StringProperty("")


# ====== التطبيق الرئيسي ======
class ManksApp(App):
    def build(self):
        self.title = "Manks Tool"
        Window.clearcolor = (0.04, 0.05, 0.08, 1)

        # التحقق من الترخيص أولاً
        if not auth.check_license(log=self._early_log):
            # إذا فشل الترخيص، نعرض رسالة ونغلق التطبيق
            root = BoxLayout(orientation='vertical', padding=dp(20), spacing=dp(10))
            root.add_widget(Label(
                text="[color=ff3333]ACCESS DENIED[/color]\n"
                     "Device not authorized or wrong password.",
                markup=True, halign='center'
            ))
            return root

        self.sm = ScreenManager(transition=SlideTransition())
        self.menu = MenuScreen(name='menu')
        self.out = OutputScreen(name='output')
        self.sm.add_widget(self.menu)
        self.sm.add_widget(self.out)
        return self.sm

    def _early_log(self, msg):
        print(msg)

    def show_output(self, title, initial_text=""):
        self.out.title_text = title
        self.out.output_text = initial_text
        self.sm.current = 'output'

    def append_output(self, text):
        self.out.output_text += text + "\n"

    def go_back(self):
        self.sm.current = 'menu'


if __name__ == '__main__':
    ManksApp().run()