# tools/auth.py
import sys
import subprocess
import requests
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.clock import Clock

ALLOWED_MODELS_URL = "https://www.manks.giize.com/2026/09/blog-post.html"

def get_device_model():
    """الحصول على طراز الجهاز"""
    try:
        from kivy.utils import platform
        if platform == 'android':
            from jnius import autoclass
            Build = autoclass('android.os.Build')
            return Build.MODEL
        else:
            return subprocess.check_output(
                ["getprop", "ro.product.model"], text=True
            ).strip() or "UNKNOWN"
    except Exception:
        return "UNKNOWN"

def check_license(log=print):
    """التحقق من الترخيص بشكل تفاعلي مع Popup"""
    model = get_device_model()
    log(f"[AUTH] Device: {model}")

    try:
        r = requests.get(ALLOWED_MODELS_URL, timeout=10)
        r.raise_for_status()
        content = r.text
    except Exception as e:
        log(f"[AUTH] Cannot download allowed list: {e}")
        return False

    entry = next((l for l in content.splitlines()
                  if l.startswith(f"{model}:")), None)
    if entry is None:
        log(f"[AUTH] Device {model} not authorized")
        return False

    stored_pw = entry.split(":", 1)[1].strip()

    # عرض Popup لإدخال كلمة المرور (متزامن)
    result = {"ok": False}

    from kivy.core.window import Window

    box = BoxLayout(orientation='vertical', spacing=10, padding=15)
    box.add_widget(Label(text=f"Password for {model}:"))
    pw_input = TextInput(password=True, multiline=False, size_hint_y=None, height=45)
    box.add_widget(pw_input)
    btns = BoxLayout(size_hint_y=None, height=45, spacing=10)
    ok_btn = Button(text="OK", background_color=(0.1, 0.6, 0.3, 1))
    cancel_btn = Button(text="CANCEL", background_color=(0.6, 0.1, 0.1, 1))
    btns.add_widget(ok_btn)
    btns.add_widget(cancel_btn)
    box.add_widget(btns)

    popup = Popup(title="🔐 AUTHENTICATION", content=box,
                  size_hint=(0.85, 0.4), auto_dismiss=False)

    def on_ok(*a):
        if pw_input.text.strip() == stored_pw:
            result["ok"] = True
            popup.dismiss()
        else:
            pw_input.text = ""
            pw_input.hint_text = "❌ Wrong password!"

    def on_cancel(*a):
        popup.dismiss()

    ok_btn.bind(on_release=on_ok)
    cancel_btn.bind(on_release=on_cancel)
    popup.open()

    # انتظار إغلاق الـ Popup
    Clock.schedule_interval(
        lambda dt: (not popup._window) and (dt_event.cancel() or True), 0.1
    ) if False else None

    # ننتظر بشكل بسيط
    import time
    while popup._window is not None:
        time.sleep(0.05)

    return result["ok"]