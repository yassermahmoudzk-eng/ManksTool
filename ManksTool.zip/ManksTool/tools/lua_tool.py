# tools/lua_tool.py
from pathlib import Path
from . import lua_core  # انقل دوال compile_single_lua/unpack_single_lua هنا


def do_compile(data_path: Path, log=print):
    src = data_path / "LUA" / "UNPACK"
    if not src.exists():
        log("❌ LUA/UNPACK/ not found")
        return
    files = [f for f in src.iterdir() if f.suffix == '.lua']
    if not files:
        log("❌ No .lua files")
        return
    for f in files:
        log(f"⚙️ Compiling {f.name}...")
        try:
            lua_core.compile_single_lua(f.name, level=2)
            log(f"✅ {f.name}")
        except Exception as e:
            log(f"❌ {f.name}: {e}")


def do_decompile(data_path: Path, log=print):
    src = data_path / "LUA" / "ORIGINAL"
    if not src.exists():
        log("❌ LUA/ORIGINAL/ not found")
        return
    files = [f for f in src.iterdir() if f.suffix == '.lua']
    if not files:
        log("❌ No .lua files")
        return
    for f in files:
        log(f"🔓 Decompiling {f.name}...")
        try:
            lua_core.unpack_single_lua(f.name)
            log(f"✅ {f.name}")
        except Exception as e:
            log(f"❌ {f.name}: {e}")