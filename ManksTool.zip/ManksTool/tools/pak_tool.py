# tools/pak_tool.py
"""
نسخة واجهة من أدوات PAK - تستدعي الدوال الأصلية من الكود الكبير.
يجب نقل الكلاسات: TencentPakFile, PakCrypto, PakInfo, PakCompression, ... إلخ
إلى هذا الملف، أو استيرادها من ملف آخر (pak_core.py).
"""

# ضع هنا كل الكلاسات الأصلية:
# TencentPakFile, PakInfo, TencentPakInfo, PakCompressedBlock,
# TencentPakEntry, PakCrypto, PakCompression, Reader, SM4, Misc

# ثم أضف دوال الواجهة:

from pathlib import Path
from . import pak_core  # افترض أنك نقلت الكود الأصلي إلى pak_core.py


def _select_pak(data_path: Path, sub="PAK"):
    pak_dir = data_path / sub
    files = list(pak_dir.glob("*.pak")) if pak_dir.exists() else []
    return files


def do_unpack(data_path: Path, log=print):
    """فتح PAK وفك كل الملفات إلى UNPACK/<name>/"""
    from . import pak_core
    files = _select_pak(data_path)
    if not files:
        log("❌ No .pak files found in PAK/")
        return
    for pak_file in files:
        log(f"📦 Unpacking {pak_file.name}...")
        pak = pak_core.TencentPakFile(pak_file)
        out = data_path / "UNPACK" / pak_file.stem
        pak.dump(out)
        log(f"✅ Extracted to {out}")


def do_repack_normal(data_path: Path, log=print):
    from . import pak_core
    files = _select_pak(data_path)
    if not files:
        log("❌ No .pak files found")
        return
    for pak_file in files:
        repack_dir = data_path / "REPACK" / pak_file.stem
        if not repack_dir.exists():
            log(f"⚠️ Skip {pak_file.name}: no REPACK folder")
            continue
        log(f"📦 Repacking {pak_file.name}...")
        pak = pak_core.TencentPakFile(pak_file, skip_validation=True)
        output = data_path / "RESULT" / pak_file.name
        pak_core.repack_pak_file_with_block_display(pak, repack_dir, output)
        log(f"✅ Saved: {output}")


def do_repack_full(data_path: Path, log=print):
    from . import pak_core
    files = _select_pak(data_path, sub="PAK TOOL/PAK")
    if not files:
        log("❌ No .pak files in PAK TOOL/PAK")
        return
    edit_dir = data_path / "PAK TOOL" / "EDIT"
    for pak_file in files:
        log(f"📦 Full repack {pak_file.name}...")
        pak = pak_core.TencentPakFile(pak_file, skip_validation=True)
        output = data_path / "PAK TOOL" / "RESULT" / pak_file.name
        count = pak_core.repack_pak_file_full(pak, edit_dir, output)
        log(f"✅ Processed {count} files → {output}")


def do_inject(data_path: Path, log=print):
    from . import pak_core
    files = _select_pak(data_path, sub="PAK TOOL/PAK")
    if not files:
        log("❌ No .pak files in PAK TOOL/PAK")
        return
    edit_dir = data_path / "PAK TOOL" / "EDIT"
    for pak_file in files:
        log(f"💉 Injecting into {pak_file.name}...")
        pak = pak_core.TencentPakFile(pak_file, skip_validation=True)
        output = data_path / "PAK TOOL" / "RESULT" / pak_file.name
        count = pak_core.repack_pak_file_full(
            pak, edit_dir, output,
            force_add=True,
            add_protection=True,
        )
        log(f"✅ Injected {count} files → {output}")